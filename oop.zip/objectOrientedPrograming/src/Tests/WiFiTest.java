package Tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class WiFiTest {

	@Test
	public void testWiFi() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetSignal() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
